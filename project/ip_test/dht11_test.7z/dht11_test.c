#include "stdio.h"
#include "xil_io.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "dht.h"
#include "sleep.h"
#include "xuartps.h"
#include "stdlib.h"

int main()
{
	while(1)
	{
		sleep(10);
		
		int humidity_int=Xil_In32(XPAR_DHT11_S00_AXI_BASEADDR);
		int humidity_dec=Xil_In32(XPAR_DHT11_S00_AXI_BASEADDR+4);
		int temperature_int=Xil_In32(XPAR_DHT11_S00_AXI_BASEADDR+8);
		int temperature_dec=Xil_In32(XPAR_DHT11_S00_AXI_BASEADDR+12);
		
		printf("Humidity:%d.%d\n" , humidity_int , humidity_dec);
		printf("temperature:%d.%d\n" , temperature_int , temperature_dec);
	}
	
	return 0;
}