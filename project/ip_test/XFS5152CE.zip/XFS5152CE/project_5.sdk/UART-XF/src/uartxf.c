/*
 * uartxf.c
 *
 *  Created on: 2024��6��1��
 *      Author: admin
 */


/*
 * mine.c
 *
 *  Created on: 2024��5��27��
 *      Author: Herman
 */


#include "stdio.h"
#include "xparameters.h"
#include "xil_io.h"
#include "sleep.h"
#include "xil_types.h"
#include "xgpiops.h"

int toBgk32bit(int num) {
int ones = num % 10;
int tens = (num / 10) % 10;
int hundreds = (num / 100) % 10;
int thousands = (num / 1000) % 10;

int rearranged = ((thousands+48) <<24) | ((hundreds+48) <<16) | ((tens+48) << 8) | (ones+48);

return rearranged;
}

int main()
{

int sign=0;
int count=1;
int result;

Xil_Out32(XPAR_ALLXFS_0_S00_AXI_BASEADDR+4,1);//encode GBK����
Xil_Out32(XPAR_ALLXFS_0_S00_AXI_BASEADDR+8,3149321133);//data_in   ����ӭ��
Xil_Out32(XPAR_ALLXFS_0_S00_AXI_BASEADDR,0);//sign=0
usleep(1000);//�ӳ�1ms
Xil_Out32(XPAR_ALLXFS_0_S00_AXI_BASEADDR,1);//sign=1
usleep(3000000);// �ӳ�����


return 0;
}
