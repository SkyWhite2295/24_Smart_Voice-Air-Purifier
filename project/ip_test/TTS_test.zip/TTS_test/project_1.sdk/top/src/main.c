#include <stdio.h>
#include "xil_io.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "tts.h"



int main()
{
	while(1){
		Init_TTS();
		sleep(2);
	}


	return 0;
}
